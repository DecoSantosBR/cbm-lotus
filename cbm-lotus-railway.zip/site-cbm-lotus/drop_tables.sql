DROP TABLE IF EXISTS course_enrollments;
DROP TABLE IF EXISTS course_events;
DROP TABLE IF EXISTS course_files;
DROP TABLE IF EXISTS course_images;
DROP TABLE IF EXISTS course_materials;
DROP TABLE IF EXISTS course_applications;
DROP TABLE IF EXISTS certificates;
DROP TABLE IF EXISTS courses;
